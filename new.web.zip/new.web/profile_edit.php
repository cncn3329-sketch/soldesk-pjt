<!DOCTYPE html>

<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>정보수정 | My Web App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap');

```
:root {
  --primary:#0072ff;
  --primary-soft:#00c6ff;
  --text:#333;
  --muted:#636e72;
  --border:#dfe6e9;
  --bg:rgba(255,255,255,0.95);
  --ok:#2ecc71;
  --err:#e74c3c;
  --ok-bg:rgba(46,204,113,.12);
  --err-bg:rgba(231,76,60,.12);
}

* { box-sizing: border-box; }

body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #74b9ff, #81ecec, #a29bfe);
  min-height: 100vh;
  margin: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  color: var(--text);
}

.container {
  background: var(--bg);
  width: 520px;
  max-width: 94%;
  border-radius: 16px;
  box-shadow: 0 8px 20px rgba(0,0,0,.15);
  padding: 28px;
}

h1 {
  font-size: 24px;
  margin: 0 0 16px;
}

form {
  display: flex;
  flex-direction: column;
}

label {
  margin: 8px 0 6px;
  color: var(--muted);
  font-weight: 500;
}

input {
  padding: 12px;
  border: 1px solid var(--border);
  border-radius: 10px;
  font-size: 15px;
  margin-bottom: 10px;
}

input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 5px rgba(0,114,255,.3);
}

.btn {
  margin-top: 8px;
  padding: 12px;
  border: none;
  border-radius: 10px;
  background: linear-gradient(90deg, var(--primary), var(--primary-soft));
  color: #fff;
  font-weight: 600;
  cursor: pointer;
  transition: .25s;
}

.btn:hover {
  background: linear-gradient(90deg, var(--primary-soft), var(--primary));
  color: #fff;
}

.link {
  margin-top: 14px;
  font-size: 14px;
}

.link a {
  color: var(--primary);
  text-decoration: none;
  font-weight: 600;
}

.link a:hover {
  text-decoration: underline;
}

.alert {
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 14px;
  display: grid;
  grid-template-columns: 36px 1fr;
  gap: 10px;
  align-items: start;
  margin-bottom: 12px;
}

.alert .icon {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  color: #fff;
  font-weight: 700;
}

.success { background: var(--ok-bg); border-color: rgba(46,204,113,.35); }
.success .icon { backgroun
```
