<!DOCTYPE html>

<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>회원가입 결과 | My Web App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap');

```
:root {
  --primary:#0072ff;
  --primary-soft:#00c6ff;
  --text:#333;
  --muted:#636e72;
  --border:#dfe6e9;
  --bg:rgba(255,255,255,0.95);
  --ok:#2ecc71;
  --err:#e74c3c;
  --ok-bg:rgba(46, 204, 113, .12);
  --err-bg:rgba(231, 76, 60, .12);
}

* { box-sizing: border-box; }

body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #74b9ff, #81ecec, #a29bfe);
  min-height: 100vh;
  margin: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text);
}

.container {
  background: var(--bg);
  width: 560px;
  max-width: 94%;
  border-radius: 16px;
  box-shadow: 0 8px 20px rgba(0,0,0,.15);
  padding: 28px;
  text-align: center;
}

h1 {
  font-size: 24px;
  margin: 0 0 10px;
}
p.lead { color: var(--muted); margin: 0 0 16px; }

.alert {
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 16px;
  text-align: left;
  margin: 14px 0 18px;
  display: grid;
  grid-template-columns: 36px 1fr;
  gap: 12px;
  align-items: start;
}
.alert .icon {
  width: 36px; height: 36px; border
```
