<?php
// config/s3.php
return [
  // ✅ S3 기본 정보
  'bucket' => 'web-7204',
  'region' => 'ap-northeast-2',
  // ✅ Access Key / Secret (여기에만!)
  'access_key' => 'AKIAZPVBO726CC475Y7S',
  'secret_key' => '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',
];